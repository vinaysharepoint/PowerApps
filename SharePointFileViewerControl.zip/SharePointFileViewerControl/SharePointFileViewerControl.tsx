import * as React from 'react';
import { useState, useEffect, useRef } from 'react';
import { initializeIcons } from '@fluentui/react/lib/Icons';
import {
  DetailsList,
  DetailsListLayoutMode,
  Selection,
  SelectionMode,
  IColumn
} from '@fluentui/react/lib/DetailsList';
import { CommandBar, ICommandBarItemProps } from '@fluentui/react/lib/CommandBar';
import { TextField } from '@fluentui/react/lib/TextField';
import { Stack, IStackTokens } from '@fluentui/react/lib/Stack';
import { Spinner, SpinnerSize } from '@fluentui/react/lib/Spinner';
import { Icon } from '@fluentui/react/lib/Icon';
import { mergeStyles } from '@fluentui/react/lib/Styling';
import { sp, SPRest } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/files";
import "@pnp/sp/folders";
import "@pnp/sp/lists";
import { IInputs } from "./generated/ManifestTypes";

// Define interface for SharePoint file data
interface ISharePointFile {
  Name: string;
  TimeLastModified: string;
  Length: number;
  ServerRelativeUrl: string;
  ModifiedBy?: {
    Title: string;
  };
}

initializeIcons();

export interface IFile {
  key: string;
  name: string;
  value: string;
  fileType: string;
  dateModified: Date;
  fileSize: number;
  modifiedBy: string;
  iconName: string;
}

export interface ISharePointFileViewerProps {
  folderUrl: string;
  context: ComponentFramework.Context<IInputs>;
  pnpContext:SPRest;
  width: number;
  height: number;
  siteUrl:string;
}

export function SharePointFileViewer(props:ISharePointFileViewerProps){
  const [files, setFiles] = useState<IFile[]>([]);
  const [columns, setColumns] = useState<IColumn[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [selection] = useState(new Selection());
  const dropzoneRef = useRef<HTMLDivElement>(null);
  const [filterText, setFilterText] = useState("");
  const [filteredFiles, setFilteredFiles] = useState<IFile[]>([]);
  
  const stackTokens: IStackTokens = { childrenGap: 10 };
  
  const dropZoneClassName = mergeStyles({
    height: props.height - 150,
    position: 'relative',
    outline: '2px dashed #c8c8c8',
    padding: '10px',
    textAlign: 'center',
    transition: 'all .15s ease-in-out',
    ':hover': {
      outlineColor: '#0078d4',
      backgroundColor: 'rgba(0, 120, 212, 0.05)'
    }
  });
  
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (dropzoneRef.current) {
      dropzoneRef.current.style.backgroundColor = 'rgba(0, 120, 212, 0.1)';
      dropzoneRef.current.style.outlineColor = '#0078d4';
    }
  };
  
  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (dropzoneRef.current) {
      dropzoneRef.current.style.backgroundColor = '';
      dropzoneRef.current.style.outlineColor = '#c8c8c8';
    }
  };
  
  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (dropzoneRef.current) {
      dropzoneRef.current.style.backgroundColor = '';
      dropzoneRef.current.style.outlineColor = '#c8c8c8';
    }
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      await uploadFiles(files);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      // Use void to ignore the promise return value
      void uploadFiles(files);
    }
  };
  
  const uploadFiles = async (files: FileList) => {
    setIsLoading(true);
    
    try {
      const folderPath = getFolderPathFromUrl(props.folderUrl);
      
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        await sp.web.getFolderByServerRelativeUrl(folderPath)
          .files.add(file.name, file, true);
      }
      
      // Refresh file list after upload
      await loadFiles();
    } catch (error) {
      console.error("Error uploading files:", error);
      alert("Error uploading files. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };
  
  const getFolderPathFromUrl = (url: string): string => {
    // Extract the server-relative path from the URL
    // This is a simplified approach, you might need to adjust based on your SharePoint configuration
    const urlObj = new URL(url);
    return urlObj.pathname;
  };
  
  const getFileIconName = (fileType: string): string => {
    const fileExtension = fileType.toLowerCase();
    if (fileExtension === 'docx' || fileExtension === 'doc') return 'WordDocument';
    if (fileExtension === 'xlsx' || fileExtension === 'xls') return 'ExcelDocument';
    if (fileExtension === 'pptx' || fileExtension === 'ppt') return 'PowerPointDocument';
    if (fileExtension === 'pdf') return 'PDF';
    if (['jpg', 'jpeg', 'png', 'gif', 'bmp'].includes(fileExtension)) return 'FileImage';
    if (['mp4', 'mov', 'wmv', 'avi'].includes(fileExtension)) return 'Video';
    if (['mp3', 'wav', 'wma'].includes(fileExtension)) return 'MusicInCollection';
    if (fileExtension === 'txt') return 'TextDocument';
    return 'FileTemplate';
  };
  
  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };
  
  const loadFiles = async () => {
    setIsLoading(true);
    
    try {
      const folderPath = getFolderPathFromUrl(props.folderUrl);
      
      
      // Initialize PnPjs
      sp.setup({
        sp: {
          headers: {
            Accept: "application/json;odata=verbose",
          },
          baseUrl: props.siteUrl
        },
      });
      
      const folderFiles = await sp.web.getFolderByServerRelativeUrl(folderPath)
        .files.select('Name', 'TimeLastModified', 'Length', 'ModifiedBy', 'ServerRelativeUrl')
        .expand('ModifiedBy')
        .get<ISharePointFile[]>();
      
      const filesData: IFile[] = folderFiles.map((file: ISharePointFile) => {
        const fileNameParts = file.Name.split('.');
        const fileType = fileNameParts.length > 1 ? fileNameParts[fileNameParts.length - 1] : '';
        
        return {
          key: file.ServerRelativeUrl,
          name: file.Name,
          value: file.ServerRelativeUrl,
          fileType: fileType,
          dateModified: new Date(file.TimeLastModified),
          fileSize: file.Length,
          modifiedBy: file.ModifiedBy ? file.ModifiedBy.Title : 'Unknown',
          iconName: getFileIconName(fileType)
        };
      });
      
      setFiles(filesData);
      setFilteredFiles(filesData);
    } catch (error) {
      console.error("Error loading files:", error);
      alert("Error loading files from SharePoint. Please check the folder URL and permissions.");
    } finally {
      setIsLoading(false);
    }
  };
  
  useEffect(() => {
    // Define columns for DetailsList
    const cols: IColumn[] = [
      {
        key: 'icon',
        name: '',
        minWidth: 32,
        maxWidth: 32,
        onRender: (item: IFile) => <Icon iconName={item.iconName} />
      },
      {
        key: 'name',
        name: 'Name',
        fieldName: 'name',
        minWidth: 200,
        isResizable: true,
        isSorted: true,
        isSortedDescending: false,
        onColumnClick: _onColumnClick,
        data: 'string',
        onRender: (item: IFile) => {
          return <span>{item.name}</span>;
        }
      },
      {
        key: 'dateModified',
        name: 'Date Modified',
        fieldName: 'dateModified',
        minWidth: 150,
        isResizable: true,
        data: 'date',
        onRender: (item: IFile) => {
          return <span>{item.dateModified.toLocaleDateString() + ' ' + item.dateModified.toLocaleTimeString()}</span>;
        },
        onColumnClick: _onColumnClick
      },
      {
        key: 'fileSize',
        name: 'File Size',
        fieldName: 'fileSize',
        minWidth: 100,
        isResizable: true,
        data: 'number',
        onRender: (item: IFile) => {
          return <span>{formatFileSize(item.fileSize)}</span>;
        },
        onColumnClick: _onColumnClick
      },
      {
        key: 'modifiedBy',
        name: 'Modified By',
        fieldName: 'modifiedBy',
        minWidth: 150,
        isResizable: true,
        data: 'string',
        onColumnClick: _onColumnClick
      }
    ];
    
    setColumns(cols);
    
    // Load files when component mounts or folderUrl changes
    if (props.folderUrl) {
      void loadFiles(); // Use void to ignore the promise
    }
  }, [props.folderUrl,props.siteUrl]);
  
  useEffect(() => {
    // Filter files when filterText changes
    if (filterText) {
      const filtered = files.filter(file => 
        file.name.toLowerCase().includes(filterText.toLowerCase()) ||
        file.modifiedBy.toLowerCase().includes(filterText.toLowerCase())
      );
      setFilteredFiles(filtered);
    } else {
      setFilteredFiles(files);
    }
  }, [filterText, files]);
  
  const _onColumnClick = (ev?: React.MouseEvent<HTMLElement>, column?: IColumn): void => {
    if (column) {
      const newColumns: IColumn[] = columns.slice();
      const currColumn: IColumn = newColumns.filter(currCol => column.key === currCol.key)[0];
      
      newColumns.forEach((newCol: IColumn) => {
        if (newCol === currColumn) {
          currColumn.isSortedDescending = !currColumn.isSortedDescending;
          currColumn.isSorted = true;
        } else {
          newCol.isSorted = false;
          newCol.isSortedDescending = true;
        }
      });
      
      const newItems = [...filteredFiles];
      newItems.sort((a: IFile, b: IFile) => {
        const firstValue = a[currColumn.fieldName as keyof IFile];
        const secondValue = b[currColumn.fieldName as keyof IFile];
        
        if (firstValue < secondValue) {
          return currColumn.isSortedDescending ? 1 : -1;
        }
        if (firstValue > secondValue) {
          return currColumn.isSortedDescending ? -1 : 1;
        }
        return 0;
      });
      
      setColumns(newColumns);
      setFilteredFiles(newItems);
    }
  };
  
  // Fixed CommandBar items to properly type with ICommandBarItemProps
  const commandItems: ICommandBarItemProps[] = [
    {
      key: 'upload',
      text: 'Upload',
      iconProps: { iconName: 'Upload' },
      onClick: () => { 
        document.getElementById('fileInput')?.click();
        return false; // Return a boolean or void to satisfy ICommandBarItemProps.onClick
      }
    },
    {
      key: 'refresh',
      text: 'Refresh',
      iconProps: { iconName: 'Refresh' },
      onClick: () => {
        void loadFiles(); // Use void to ignore the promise
        return false; // Return a boolean or void to satisfy ICommandBarItemProps.onClick
      }
    }
  ];
  
  return (
    <Stack tokens={stackTokens}>
      <CommandBar items={commandItems} />
      
      <TextField 
        label="Filter files" 
        placeholder="Type to filter..." 
        onChange={(_, newValue) => setFilterText(newValue || '')}
        iconProps={{ iconName: 'Filter' }}
      />
      
      <input
        type="file"
        id="fileInput"
        multiple
        style={{ display: 'none' }}
        onChange={handleFileSelect}
      />
      
      <div 
        ref={dropzoneRef}
        className={dropZoneClassName}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {isLoading ? (
          <Spinner size={SpinnerSize.large} label="Loading files..." />
        ) : (
          <>
            <DetailsList
              items={filteredFiles}
              columns={columns}
              selection={selection}
              selectionMode={SelectionMode.single}
              layoutMode={DetailsListLayoutMode.justified}
              isHeaderVisible={true}
            />
            {filteredFiles.length === 0 && (
              <div style={{ padding: '20px', textAlign: 'center' }}>
                <Icon iconName="FolderOpen" style={{ fontSize: '32px', marginBottom: '10px' }} />
                <p>No files found. Drag and drop files here to upload.</p>
              </div>
            )}
          </>
        )}
      </div>
    </Stack>
  );
}